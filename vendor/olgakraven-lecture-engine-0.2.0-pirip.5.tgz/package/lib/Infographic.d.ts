import type { Visual } from './model';
export type DiagramView = 'diagram' | 'text' | null;
export declare const DiagramControl: import("react").Context<{
    view: DiagramView;
    setView: (view: DiagramView) => void;
} | null>;
export declare function Infographic({ visual, base, slideId, interactive }: {
    visual: Visual;
    base?: string;
    slideId?: string;
    interactive?: boolean;
}): import("react").JSX.Element;
