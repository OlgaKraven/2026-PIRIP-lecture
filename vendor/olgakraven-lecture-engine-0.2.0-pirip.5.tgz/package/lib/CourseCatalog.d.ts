import type { ReactNode } from 'react';
import type { Course, Lecture, Profile } from './model';
export declare function CourseCatalog({ course, base, profile, materials, themeButton, onOpen, onPrint, onSettings, invalidLecture }: {
    course: Course;
    base: string;
    profile: Profile;
    materials: string;
    themeButton: ReactNode;
    onOpen: (lecture: Lecture) => void;
    onPrint: (scope: string) => void;
    onSettings: () => void;
    invalidLecture: boolean;
}): import("react").JSX.Element;
