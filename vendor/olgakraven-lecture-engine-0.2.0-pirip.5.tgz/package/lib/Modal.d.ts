import type { ReactNode } from 'react';
export declare function Modal({ title, onClose, children, wide, closable, }: {
    title: string;
    onClose: () => void;
    children: ReactNode;
    wide?: boolean;
    closable?: boolean;
}): import("react").JSX.Element;
