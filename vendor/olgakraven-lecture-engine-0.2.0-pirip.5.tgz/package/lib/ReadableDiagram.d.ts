import type { Visual } from './model';
export declare function diagramSteps(v: Visual): number;
export declare function ReadableDiagram({ visual: v, base, step }: {
    visual: Visual;
    base: string;
    step?: number;
}): import("react").JSX.Element;
